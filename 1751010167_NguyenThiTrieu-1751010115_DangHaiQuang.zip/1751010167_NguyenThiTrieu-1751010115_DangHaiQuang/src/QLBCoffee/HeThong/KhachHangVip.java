package QLBCoffee.HeThong;

import java.util.ArrayList;

public class KhachHangVip extends KhachHang {
	private double chiecKhau;
	ArrayList<KhachHangVip> ds = new ArrayList<>();

	public KhachHangVip(String ten, String ns, int sdt) {
		super(ten, ns, sdt);
	}
	public void ThemKhachHangVip(KhachHangVip khv)
	{
		if (this.soDiemTich >= 200){
		    this.ds.add(khv);
        }
	}
}