package QLBCoffee.HeThong;

import java.util.Random;

public class DatMon {
	Random rand = new Random();
	protected int maBan = 0;
	protected String tenSanPham;
	protected int soLuong;
	public DatMon(){
		maBan = 1 +  rand.nextInt(20);
	}
	public DatMon(String tsp,int slg){
		this();
		this.tenSanPham = tsp;
		this.soLuong = slg;
	}
	public int getMaBan() {
		return this.maBan;
	}

	public void setMaBan(int maBan) {
		this.maBan = maBan;
	}

	public String getTenSanPham() {
		return this.tenSanPham;
	}

	public void setTenSanPham(String tenSanPham) {
		this.tenSanPham = tenSanPham;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
}