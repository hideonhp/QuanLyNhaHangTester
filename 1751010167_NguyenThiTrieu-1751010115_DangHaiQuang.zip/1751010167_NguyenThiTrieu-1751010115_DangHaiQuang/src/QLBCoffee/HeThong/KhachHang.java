package QLBCoffee.HeThong;

public class KhachHang {

	private static int maKH = 0;
	protected String tenKH;
	protected String ngaySinh;
	protected int soDiemTich;

	public KhachHang (String ten, String ns, int sdt){
		maKH++;
		this.tenKH = ten;
		this.ngaySinh = ns;
		this.soDiemTich = sdt;
	}

}