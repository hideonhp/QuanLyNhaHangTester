package QLBCoffee.HeThong;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;

public class TaiQuan extends DatBan {
	Random rand = new Random();
	ArrayList<DatBan> ds = new ArrayList<>();
	private int soDat;

	public TaiQuan() throws FileNotFoundException {
		super();
		this.setSoDat(soDat);
	}
	public TaiQuan(String tsp, int slg) throws FileNotFoundException {
		super(tsp, slg);

	}

	public int getSoDat() {
		return this.soDat;
	}

	public void setSoDat(int soDat) {
		this.soDat = soDat;
	}

	public void them() throws FileNotFoundException {
		TaiQuan tq = new TaiQuan();
		if(getSoDat() != 0)
			this.ds.add(tq);
	}
}