package QLBCoffee.HeThong;


import QLBCoffee.HeThong.NhanVien.NhanVien;
import QLBCoffee.HeThong.SanPham.QLSanPham;
import QLBCoffee.HeThong.SanPham.SanPham;
import QLBCoffee.HeThong.SanPham.TaoHoaDonThucAn;
import QLBCoffee.HeThong.SanPham.TaoHoaDonThucUong;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class HoaDon {

	protected static int maHoaDon = 0;
	protected String tenNV;
	protected String maBan;
	protected int tongTien;
	protected int tienTra;
	protected int tienDu;
	protected int maKH;
	protected Date ngayBan;
	SanPham sp = new SanPham();
	NhanVien nv = new NhanVien();
	DatBan db = new DatBan();
	java.util.Date date = new java.util.Date();
	QLSanPham qlsp = new QLSanPham();
	TaoHoaDonThucAn thda = new TaoHoaDonThucAn();
	TaoHoaDonThucUong thdu = new TaoHoaDonThucUong();
	public HoaDon() throws FileNotFoundException {
		maHoaDon++;
	}
	public HoaDon( String mnv, String mb,int tgtien, int tientra, int tiendu, int mkh) throws FileNotFoundException {
		this();
		this.setTenNV(mnv);
		this.setMaBan(mb);
		this.setTongTien(tgtien);
		this.setTienTra(tientra);
		this.setTienDu(tiendu);
		this.setMaKH(mkh);
		this.ngayBan = date;
	}

	public int tongTien(){
		int kq = 0;
		return kq = sp.soLuong * sp.giaBan;
	}
	public String getTenNV() {
		return this.tenNV;
	}

	public void setTenNV(String maNhanVien) {
		this.tenNV = maNhanVien;
	}

	public String getMaBan() {
		return this.maBan;
	}

	public void setMaBan(String maBan) {
		this.maBan = maBan;
	}

	public int getMaKH() {
		return this.maKH;
	}

	public void setMaKH(int maKH) {
		this.maKH = maKH;
	}

	public int getMaHoaDon() {
		return this.maHoaDon;
	}

	public void setMaHoaDon(int maHoaDon) {
		this.maHoaDon = maHoaDon;
	}

	public int getTongTien() {
		return tongTien;
	}

	public void setTongTien(int tongTien) {
		this.tongTien = tongTien;
	}

	public int getTienTra() {
		return tienTra;
	}

	public void setTienTra(int tienTra) {
		this.tienTra = tienTra;
	}

	public int getTienDu() {
		return tienDu;
	}

	public void setTienDu(int tienDu) {
		this.tienDu = tienDu;
	}

	public Date getNgayBan() {
		return ngayBan;
	}

	public void setNgayBan(Date ngayBan) {
		this.ngayBan = ngayBan;
	}
	public void Nhap(Scanner scanner) throws FileNotFoundException {
		// TODO - implement NhanVien.Them
//		System.out.println("Nhập nhân viên đứng quầy: ");
//		this.tenNV = scanner.nextLine();
		do{
				System.out.println("Chọn loại sản phẩm:\n" +
						"1.Thúc ăn\n" +
						"2.Thức uống");
				int chon = Integer.parseInt(scanner.nextLine());
				switch (chon){
					case 1:
						thda.NhapThongTinThucAn(scanner);
						break;
					case 2:
						thdu.NhapThongTinThucUong(scanner);
						break;
				}
				System.out.println(qlsp);
				System.out.println("Muốn thêm món ăn(Y/N)");
				String chon2 = scanner.nextLine();
				if(!chon2.equalsIgnoreCase("y"))
				break;
		}while (true);
		System.out.println("Nhập tiên khách đưa: ");
		this.tienTra = Integer.parseInt(scanner.nextLine());
	}

	@Override
	public String toString() {
		String kq = String.format("Nhân viên: %s\nMã bàn: %d\n%s\n%s\nTổng tiền: %s\nTiền khách đưa: %d\nTiền dư: %d\nNgày bán :%s", nv.hoTenNhanVien
		,db.maBan,thda,thdu,thdu.tongTien+thda.tongTien,this.tienTra,this.tienDu,this.ngayBan);
		return kq;
	}
}