package QLBCoffee.HeThong;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Date;

public class PhanCong {

	protected Date ngayPC;
	private String caLam;
	ArrayList<NhanVien> dsls = new ArrayList<>();
	ArrayList<NhanVien> dslt = new ArrayList<>();
	public PhanCong(){

	}
	public void NhapCa(Scanner scanner) throws ParseException {
		System.out.println("Nhập ngày làm: ");
		String ngaylam = scanner.nextLine();
		SimpleDateFormat ns = new SimpleDateFormat("dd/mm/yyyy");
		this.ngayPC = ns.parse(ngaylam);
		System.out.println("Nhập ca làm:");
		this.caLam = scanner.nextLine();
	}
	public void ThemCaSang() {
		// TODO - implement PhanCong.ThemCa
		NhanVien nv = new NhanVien();
		if(caLam == "sáng")
			this.dsls.add(nv);
	}
	public void ThemCaToi() {
		// TODO - implement PhanCong.ThemCa
		NhanVien nv = new NhanVien();
		if(caLam == "tối")
			this.dslt.add(nv);
	}

	@Override
	public String toString() {
		String kq;
		NhanVien nv = new NhanVien();
		if(nv.ca.caLam == "sáng")
			 kq = "Sáng";
		else
			 kq = "Chiều";
		return kq;
	}
}