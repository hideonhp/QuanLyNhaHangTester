package QLBCoffee.HeThong;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class QLSanPham {
    private ArrayList<SanPham> ds = new ArrayList<>();
    public void them(SanPham sp) {
        // TODO - implement SanPham.Them
        this.ds.add(sp);
    }
    public void nhapSanPham(Scanner scanner) throws ParseException {
        do {
            SanPham sp = new SanPham();
            sp.NhapSP(scanner);
            them(sp);
            System.out.println("Muốn tiếp tục?(Y/N)");
            String chon = scanner.nextLine();
            if (!chon.equalsIgnoreCase("y"))
                break;
        } while (true);
    }
    public void xoa(SanPham sp) {
        // TODO - implement SanPham.Xoa
        this.ds.remove(sp);
    }

    public QLSanPham timKiem(String kw) {
        // TODO - implement SanPham.TimKiem
        QLSanPham qlsp = new QLSanPham();
        for (SanPham sp:this.ds)
            if(sp.getTenSP().contains(kw))
                qlsp.them(sp);
            return qlsp;
    }

    @Override
    public String toString() {
        String kq = "";
        for(SanPham sp: this.ds)
            kq += sp +"\n";
        return kq;
    }
}
