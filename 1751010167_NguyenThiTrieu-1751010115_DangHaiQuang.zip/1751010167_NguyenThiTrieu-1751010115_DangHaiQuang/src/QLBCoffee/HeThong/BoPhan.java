package QLBCoffee.HeThong;

public class BoPhan {

	private static int maBoPhan;
	private String tenBoPhan;

	public void Them() {
		// TODO - implement BoPhan.Them
		throw new UnsupportedOperationException();
	}

	public void Xoa() {
		// TODO - implement BoPhan.Xoa
		throw new UnsupportedOperationException();
	}

}