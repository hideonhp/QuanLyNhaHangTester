package QLBCoffee.HeThong;

import QLBCoffee.HeThong.SanPham.SanPham;
import QLBCoffee.HeThong.SanPham.TaoHoaDonThucAn;
import QLBCoffee.HeThong.SanPham.TaoHoaDonThucUong;

import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;


public class DatBan {
	Random rand = new Random();
	protected int maBan = 0;
	protected String tenSanPham;
	protected int soLuong;
	SanPham sp = new SanPham();
	TaoHoaDonThucUong thdu = new TaoHoaDonThucUong();
	TaoHoaDonThucAn thda = new TaoHoaDonThucAn();
	public DatBan() throws FileNotFoundException {
		maBan = 1 +  rand.nextInt(20);
	}
	public DatBan(String tsp, int slg) throws FileNotFoundException {
		this();
		this.tenSanPham = tsp;
		this.soLuong = slg;
	}
	public int getMaBan() {
		return this.maBan;
	}

	public void setMaBan(int maBan) {
		this.maBan = maBan;
	}

	public String getTenSanPham() {
		return this.tenSanPham;
	}

	public void setTenSanPham(String tenSanPham) {
		this.tenSanPham = tenSanPham;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
	public void Nhap(Scanner scanner) throws FileNotFoundException {
		// TODO - implement NhanVien.Them
			System.out.println("Chọn loại sản phẩm:\n" +
					"1.Thúc ăn\n" +
					"2.Thức uống");
			int chon = Integer.parseInt(scanner.nextLine());
			switch (chon){
				case 1:
					thda.NhapThongTinThucAn(scanner);
					break;
				case 2:
					thdu.NhapThongTinThucUong(scanner);
					break;
			}
		}

	@Override
	public String toString() {
		String kq = String.format("Mã bàn: %d\n%s\n%s",this.maBan,thda,thdu);
		return kq;
	}
}