package QLBCoffee.HeThong;

import QLBCoffee.HeThong.NhanVien.NhanVien;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class QLHoaDon {
    ArrayList<HoaDon> ds = new ArrayList<>();

    public QLHoaDon() throws FileNotFoundException {
    }

    public void themHD(HoaDon hd) {
        // TODO - implement HoaDon.ThemHD
        this.ds.add(hd);
    }

    public void xoaHD() {
        // TODO - implement HoaDon.XoaHD
        throw new UnsupportedOperationException();
    }

    public boolean checkKHVip() {
        // TODO - implement HoaDon.CheckKHVip
        throw new UnsupportedOperationException();
    }
    public void nhapHoaDon(Scanner scanner) throws ParseException, FileNotFoundException {
            HoaDon hd = new HoaDon();
            hd.Nhap(scanner);
            themHD(hd);
    }

    @Override
    public String toString() {
        String kq = "";
        for(HoaDon hd:this.ds)
            kq += hd + "\n";
        return kq;
    }
}
