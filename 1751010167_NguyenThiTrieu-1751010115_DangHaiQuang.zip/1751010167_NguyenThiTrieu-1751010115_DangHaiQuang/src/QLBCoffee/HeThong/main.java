package QLBCoffee.HeThong;

import QLBCoffee.HeThong.KhachHang.QLKhachHang;
import QLBCoffee.HeThong.NhanVien.DsNhanVien;
import QLBCoffee.HeThong.NhanVien.NhanVien;
import QLBCoffee.HeThong.NhanVien.PhanCong;
import QLBCoffee.HeThong.SanPham.QLSanPham;
import QLBCoffee.HeThong.SanPham.SanPham;
import QLBCoffee.HeThong.SanPham.ThucAn;
import QLBCoffee.HeThong.SanPham.ThucUong;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class main {
    public static void main (String[] args) throws FileNotFoundException {
        try {
            Scanner s = new Scanner(System.in);
            SimpleDateFormat f = new SimpleDateFormat("dd/mm/yyyy");
            DsNhanVien dsnv = new DsNhanVien(); // dsnv: danh sách nhân viên
            QLSanPham dssp = new QLSanPham(); // dssp: danh sách sản phẩm
            QLKhachHang dskh = new QLKhachHang(); // dskh: danh sách khách hàng
            QLBan dsdb = new QLBan(); // dsdb: danh sách đặt bàn
            QLHoaDon dshd = new QLHoaDon(); //dshd: danh sách hóa đơn
            PhanCong pc1 = new PhanCong(f.parse("21/1/2019"),"chiều");
            PhanCong pc2 = new PhanCong(f.parse("2/1/2019"),"sáng");
            SanPham sp1 = new ThucAn("Chuối", 10, "sáng", "Còn");
            SanPham sp2 = new ThucAn("Táo", 10, "chiều", "Hết");
            dssp.them(sp1);
            dssp.them(sp2);
            SanPham sp3 = new ThucUong("Nước chanh", 20, "sáng", "Còn");
            SanPham sp4 = new ThucUong("Cam", 20, "chiều", "Hết");
            dssp.them(sp3);
            dssp.them(sp4);
            NhanVien nv1 = new NhanVien("Đặng Hải Quang", "Nam", f.parse("21/9/1999"), f.parse("20/10/2018"),"Bán Hàng",pc1,"Hô Chí Minh");
            NhanVien nv2 = new NhanVien("Nguyễn Thị Triệu", "Nữ", f.parse("2/7/1999"), f.parse("29/9/2018"),"Bán Hàng",pc2,"Hô Chí Minh");
            dsnv.themNhanVien(nv1);
            dsnv.themNhanVien(nv2);
            TKDT tk = new TKDT();
            int tongTien = 0;
            boolean check = true;
            System.out.println(dssp);
            do {
                System.out.println("============Quản lý============");
                System.out.println("1.Thêm sản phẩm");
                System.out.println("2.Thêm nhân viên");
                System.out.println("3.Thêm Khách hàng");
                System.out.println("4.Đặt bàn");
                System.out.println("5.In hóa đơn");
                System.out.println("6.Thống kê doanh thu");
                System.out.println("7.Thoát");
                System.out.println("===============================");
                System.out.println("Chọn từ 1 đến 7 : ");
                int choose = Integer.parseInt(s.nextLine());
                switch (choose) {
                    case 1:
                        try {
                            System.out.println("Chọn nhập:\n" +
                                    "1.Thúc ăn\n" +
                                    "2.Thức uống");
                            int chon = Integer.parseInt(s.nextLine());
                            switch (chon){
                                case 1:
                                    dssp.nhapThucAn(s);
                                    break;
                                case 2:
                                    dssp.nhapThucUong(s);
                                    break;
                            }
                            System.out.println(dssp);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            dsnv.nhapNhanVien(s);
                            System.out.println(dsnv);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        try {
                            dskh.nhapKhachHang(s);
                            System.out.println(dskh);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 4:
                        try {
                            dsdb.nhapBan(s);
                            System.out.println(dsdb);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 5:
                        try {
                            dshd.nhapHoaDon(s);
                            for(SanPham sp : dssp){
                                if(sp.timKiem(s.nextLine())== )
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        System.out.println(dshd);
                        System.out.println(tongTien);
                        break;
                    case 6:
                        tk.Nhap(s);
                        System.out.println(tk);
                        break;
                    case 7:
                        check = false;
                        break;
                }
            } while (check);
        }
        catch(ParseException e) {
            e.printStackTrace();
        }
    }
}
