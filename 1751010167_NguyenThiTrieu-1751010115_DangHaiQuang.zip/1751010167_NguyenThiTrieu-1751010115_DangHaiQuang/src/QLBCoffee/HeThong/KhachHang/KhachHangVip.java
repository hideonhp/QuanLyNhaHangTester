package QLBCoffee.HeThong.KhachHang;

import java.util.ArrayList;
import java.util.Date;

public class KhachHangVip extends KhachHang {
	private double chiecKhau;
	ArrayList<KhachHangVip> ds = new ArrayList<>();

	public KhachHangVip(String ten, Date ns, int sdt) {
		super(ten, ns, sdt);
	}
	public void ThemKhachHangVip(KhachHangVip khv)
	{
		if (this.soDiemTich >= 200){
		    this.ds.add(khv);
        }
	}
}