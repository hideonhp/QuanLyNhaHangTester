package QLBCoffee.HeThong.KhachHang;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class KhachHang {

	private static int maKH = 0;
	protected String tenKH;
	protected Date ngaySinh;
	protected String gioiTinh;
	protected int soDiemTich;
	public KhachHang(){
		maKH++;
	}

	public KhachHang (String ten, Date ns, int sdt){
		this();
		this.tenKH = ten;
		this.ngaySinh = ns;
		this.soDiemTich = sdt;
	}
	public void Nhap(Scanner scanner) throws ParseException {
		// TODO - implement NhanVien.Them
		System.out.println("Họ tên :");
		this.tenKH = scanner.nextLine();
		System.out.println("Giới tính :");
		this.gioiTinh = scanner.nextLine();
		System.out.println("Ngày sinh :");
		String ngsinh = scanner.nextLine();
		SimpleDateFormat f = new SimpleDateFormat("dd/mm/yyyy");
		this.ngaySinh = f.parse(ngsinh);
		System.out.println("Số điểm tích: ");
		this.soDiemTich = Integer.parseInt(scanner.nextLine());
	}

	@Override
	public String toString() {
		String kq = String.format("Họ tên khách hàng: %s\nGiới tính: %s\nNgày sinh: %s\nSố điểm đã tích: %s",this.tenKH,this.gioiTinh,this.ngaySinh,this.soDiemTich);
		return kq;
	}
}