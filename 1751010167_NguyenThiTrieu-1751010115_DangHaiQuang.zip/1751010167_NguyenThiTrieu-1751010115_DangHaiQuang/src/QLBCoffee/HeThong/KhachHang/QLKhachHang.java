package QLBCoffee.HeThong.KhachHang;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class QLKhachHang {
    private ArrayList<KhachHang> ds = new ArrayList<>();
    public void themKhachHang(KhachHang nh){
        this.ds.add(nh);
    }
    public void xoaKhachHang(KhachHang nh){
        this.ds.remove(nh);
    }
    public void nhapKhachHang(Scanner scanner) throws ParseException {
        do {
            KhachHang nh = new KhachHang();
            nh.Nhap(scanner);
            themKhachHang(nh);
            System.out.println("Muốn tiếp tục?(Y/N)");
            String chon = scanner.nextLine();
            if (!chon.equalsIgnoreCase("y"))
                break;
        } while (true);
    }
    public QLKhachHang TimKiem(String kw){
        QLKhachHang ds = new QLKhachHang();
        for (KhachHang kh: this.ds)
            if(kh.tenKH.contains(kw) ||kh.ngaySinh.equals(kw))
                ds.themKhachHang(kh);
        return ds;
    }
    public void xoaKhachHangTrDS(KhachHang kh){
            if (this.ds.contains(kh))
                xoaKhachHang(kh);
    }

    @Override
    public String toString() {
        String kq = "";
        for (KhachHang kh : this.ds)
            kq += kh + "\n";
        return kq;
    }
}
