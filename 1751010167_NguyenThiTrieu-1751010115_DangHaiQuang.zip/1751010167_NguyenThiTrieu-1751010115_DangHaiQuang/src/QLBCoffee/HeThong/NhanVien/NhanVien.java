package QLBCoffee.HeThong.NhanVien;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class NhanVien {

	protected static int maNhanVien = 0;
	public String hoTenNhanVien;
	protected String gioiTinh;
	protected Date ngaySinh;
	protected Date ngayVaoLam;
	protected String boPhanTrucThuoc;
	protected PhanCong ca = new PhanCong();
	protected String queQuan;

	public NhanVien(){
		maNhanVien++;
	}
	public NhanVien(String ht, String gt, Date ns, Date nvl, String bp,PhanCong ca, String qq)
	{
		this();
		this.hoTenNhanVien = ht;
		this.gioiTinh = gt;
		this.ngaySinh = ns;
		this.ngayVaoLam = nvl;
		this.boPhanTrucThuoc = bp;
		this.ca = ca;
		this.queQuan = qq;
	}
	public int getMaNhanVien() {
		return this.maNhanVien;
	}

	public void setMaNhanVien(int maNhanVien) {
		this.maNhanVien = maNhanVien;
	}

	public String getHoTenNhanVien() {
		return this.hoTenNhanVien;
	}

	public void setHoTenNhanVien(String hoTenNhanVien) {
		this.hoTenNhanVien = hoTenNhanVien;
	}

	public String getGioiTinh() {
		return this.gioiTinh;
	}

	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}

	public Date getNgaySinh() {
		return this.ngaySinh;
	}

	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	public Date getNgayVaoLam() {
		return this.ngayVaoLam;
	}

	public void setNgayVaoLam(Date ngayVaoLam) {
		this.ngayVaoLam = ngayVaoLam;
	}

	public String getBoPhanTrucThuoc() {
		return this.boPhanTrucThuoc;
	}

	public void setBoPhanTrucThuoc(String boPhanTrucThuoc) {
		this.boPhanTrucThuoc = boPhanTrucThuoc;
	}

	public String getQueQuan() {
		return this.queQuan;
	}

	public void setQueQuan(String queQuan) {
		this.queQuan = queQuan;
	}

	public void Nhap(Scanner scanner) throws ParseException {
		// TODO - implement NhanVien.Them
		System.out.println("Họ tên :");
		this.hoTenNhanVien = scanner.nextLine();
		System.out.println("Giới tính :");
		this.gioiTinh = scanner.nextLine();
		System.out.println("Ngày sinh :");
		String ngsinh = scanner.nextLine();
		SimpleDateFormat f = new SimpleDateFormat("dd/mm/yyyy");
		this.ngaySinh = f.parse(ngsinh);
		System.out.println("Ngày vào làm :");
		String ngvl = scanner.nextLine();
		SimpleDateFormat g = new SimpleDateFormat("dd/mm/yyyy");
		this.ngayVaoLam = g.parse(ngvl);
		System.out.println("Bộ Phận :");
		this.boPhanTrucThuoc = scanner.nextLine();
		this.ca.NhapCa(scanner);
		System.out.println("Quên Quán :");
		this.queQuan = scanner.nextLine();
	}
	@Override
	public String toString() {
		String kq = String.format("Mã Nhân viên: %s\nTên Nhân viên: %s\nGiới tính: %s\nNgày sinh: %s\nNgày vào làm: %s\nBộ phận: %s\nNgày bắt đầu ca: %s\nCa : %s\nQuê quán: %s"
				,this.maNhanVien, this.hoTenNhanVien,this.gioiTinh,this.ngaySinh,this.ngayVaoLam,this.boPhanTrucThuoc,this.ca.ngayPC,this.ca,this.queQuan);
		return kq;
	}

	public PhanCong getCa() {
		return ca;
	}

	public void setCa(PhanCong ca) {
		this.ca = ca;
	}
}