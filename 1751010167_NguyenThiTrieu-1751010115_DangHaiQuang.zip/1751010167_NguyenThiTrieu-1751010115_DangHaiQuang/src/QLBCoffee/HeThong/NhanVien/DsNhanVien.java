package QLBCoffee.HeThong.NhanVien;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class DsNhanVien {
    private ArrayList<NhanVien> ds = new ArrayList<>();
    public void themNhanVien(NhanVien nh){
        this.ds.add(nh);
    }
    public void xoaNhanViem(NhanVien nh){
        this.ds.remove(nh);
    }
    public void nhapNhanVien(Scanner scanner) throws ParseException {
        do {
            NhanVien nh = new NhanVien();
            nh.Nhap(scanner);
            themNhanVien(nh);
            System.out.println("Muốn tiếp tục?(Y/N)");
            String chon = scanner.nextLine();
            if (!chon.equalsIgnoreCase("y"))
                break;
        } while (true);
    }
    public DsNhanVien TimKiem(String kw){
        DsNhanVien ds = new DsNhanVien();
        for (NhanVien nh: this.ds)
            if(nh.getHoTenNhanVien().contains(kw) || nh.getQueQuan().contains(kw))
                ds.themNhanVien(nh);
        return ds;
    }
    public void xoaNhanVienTrDS(NhanVien nh){
            if (this.ds.contains(nh))
                xoaNhanViem(nh);
    }

    @Override
    public String toString() {
        String kq = "";
        for (NhanVien nh : this.ds)
            kq += nh + "\n";
        return kq;
    }
}
