package QLBCoffee.HeThong;

import java.util.ArrayList;

public class ThucAn extends SanPham {
	ArrayList<SanPham> ds = new ArrayList<>();
	ArrayList<SanPham> dsdc = new ArrayList<>();	//dsdc = danh sách đồ chay
	ArrayList<SanPham> dsdm = new ArrayList<>();	//dsdm = danh sách đồ mặn
	SanPham sp = new SanPham(this.getMaSP(),this.getTenSP(),this.getGiaBan());
	public ThucAn(String msp,String tsp, int gb, String tdb){
		super(msp,tsp, gb, tdb);

	}
	//Kiểm tra thức ăn
	public void CheckFood() {
		// TODO - implement ThucAn.CheckFood
		if(sp.getMaSP().startsWith("ta"))
			this.ds.add(sp);
	}
	public void SortChay(){
		if(sp.getMaSP().startsWith("ta1"))
			this.dsdc.add(sp);
		else
			this.dsdm.add(sp);
	}
}