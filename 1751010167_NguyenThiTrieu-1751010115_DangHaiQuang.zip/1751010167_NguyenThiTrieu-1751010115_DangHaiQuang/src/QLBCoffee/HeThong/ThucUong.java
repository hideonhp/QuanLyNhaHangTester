package QLBCoffee.HeThong;

public class ThucUong extends SanPham {

	public boolean CheckIce() {
		// TODO - implement ThucUong.CheckIce
		throw new UnsupportedOperationException();
	}

}