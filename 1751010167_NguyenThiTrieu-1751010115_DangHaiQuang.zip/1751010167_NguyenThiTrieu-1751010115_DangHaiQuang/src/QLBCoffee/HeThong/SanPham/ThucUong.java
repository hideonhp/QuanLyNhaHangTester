package QLBCoffee.HeThong.SanPham;

import QLBCoffee.HeThong.SanPham.SanPham;

import java.util.ArrayList;
import java.util.Scanner;

public class ThucUong extends SanPham {
	private static int dem = 0;
	private int maTU ;
	{dem++; maTU=dem;}
	private boolean da = false;
	ArrayList<SanPham> ds = new ArrayList<>();
	ArrayList<SanPham> dscd = new ArrayList<>();	//dscd = danh sách có đá
	ArrayList<SanPham> dskd = new ArrayList<>();	//dskd = danh sách không đá
	public ThucUong(){
		super();
	}
	public ThucUong(String tsp, int gb, String tdb, String ttb){
		super(tsp, gb, tdb, ttb);
	}
	public String MaTU(){
		String kq = Integer.toString(this.maTU);
		if(kq.matches("\\d{1}"))
			kq = "TU00" + kq;
		else if(kq.matches("\\d{2}"))
			kq = "TU0" + kq;
		return kq;
	}
	public void Them(ThucUong tu){
		if(da = true)
			this.dscd.add(tu);
		else
			this.dskd.add(tu);
	}

	public void NhapThucUong(Scanner scanner){
		MaTU();
		System.out.println("Nhập tên thức uống: ");
		this.tenSP = scanner.nextLine();
		System.out.println("Nhập giá bán: ");
		this.giaBan = Integer.parseInt(scanner.nextLine());
		System.out.println("Thời điểm bán: ");
		this.thoiDiemBan = scanner.nextLine();
		System.out.println("Tình trạng(còn/hết): ");
		this.tinhTrang = scanner.nextLine();
		System.out.println("Có đá(Y/N)");
		String chon2 = scanner.nextLine();
		if(!chon2.equalsIgnoreCase("y"))
		{this.da = false;}
		else
			this.da = true;
	}
	public void NhapTT(Scanner scanner) {
		System.out.println("Nhập tên thức uống: ");
		this.tenSP = scanner.nextLine();
		System.out.println("Nhập số lượng: ");
		this.soLuong = Integer.parseInt(scanner.nextLine());
	}
	@Override
	public String toString() {
		if(this.da = true)
			return super.toString() + "\nCó đá\nMã sản phẩm: "+ MaTU();
		else
			return super.toString() + "\nKhông đá\nMã sản phẩm: "+ MaTU();
	}
}