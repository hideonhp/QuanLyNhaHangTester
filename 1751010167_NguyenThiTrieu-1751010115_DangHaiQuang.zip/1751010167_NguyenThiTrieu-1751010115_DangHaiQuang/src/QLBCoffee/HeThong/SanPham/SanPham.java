package QLBCoffee.HeThong.SanPham;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class SanPham {

	//protected String maSP ;
	public String tenSP;
	public int giaBan;
	protected String tinhTrang;
	protected String thoiDiemBan;
	public int soLuong;
	public SanPham(){

	}

	public SanPham(String tsp, int gb, String tdb,String ttb) {
		this.setTenSP(tsp);
		this.setGiaBan(gb);
		this.thoiDiemBan = tdb;
		this.tinhTrang = ttb;
	}
	public SanPham(String tsp, int gb){
		this.setTenSP(tsp);
		this.setGiaBan(gb);
	}
	public String getTenSP() {
		return this.tenSP;
	}

	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}

	public int getGiaBan() {
		return this.giaBan;
	}

	public void setGiaBan(int giaBan) {
		this.giaBan = giaBan;
	}
	@Override
	public String toString() {
		String kq = String.format("Tên sản phẩm: %s\nGía bán: %s\nThời điểm bán: %s\nTình trạng: %s",
				this.tenSP,this.giaBan,this.thoiDiemBan,this.tinhTrang);
		return kq;
	}
}