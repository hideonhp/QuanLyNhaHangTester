package QLBCoffee.HeThong.SanPham;

import java.util.ArrayList;
import java.util.Scanner;


public class TaoHoaDonThucUong {
    ArrayList<ThucUong> dstu = new ArrayList<>();
    ArrayList<SanPham> ds = new ArrayList<>();
    QLSanPham qlsp = new QLSanPham();
    public int tongTien = 0;
    public void ThemTU(ThucUong tu){
        this.dstu.add(tu);
    }
    public void NhapThongTinThucUong(Scanner scanner){
        ThucUong sp = new ThucUong();
        sp.NhapTT(scanner);
        ThemTU(sp);


    }

    @Override
    public String toString() {
        String kq = "";
        for (ThucUong tu: this.dstu)
            kq += "Tên sản phẩm: " + tu.tenSP + "\n"+ "Số lượng: " +  tu.soLuong;
        return  kq;
    }
}
