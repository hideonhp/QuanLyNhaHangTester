package QLBCoffee.HeThong.SanPham;

import QLBCoffee.HeThong.HoaDon;

import java.util.ArrayList;
import java.util.Scanner;

public class TaoHoaDonThucAn {
    ArrayList<ThucAn> dsta = new ArrayList<>();
    ArrayList<SanPham> ds = new ArrayList<>();
    public int tongTien = 0;
    public void ThemTA(ThucAn ta) {
        this.dsta.add(ta);
    }

    public void NhapThongTinThucAn(Scanner scanner){
        ThucAn sp = new ThucAn();
        sp.NhapTT(scanner);
        for(SanPham ql:this.ds)
        {
            if(ql.tenSP == scanner.nextLine());
            tongTien += ql.giaBan;
        }
        ThemTA(sp);
        tongTien += sp.giaBan;
    }

    @Override
    public String toString() {
        String kq = "";
        for (ThucAn ta: this.dsta)
            kq += "Tên sản phẩm: " + ta.tenSP + "\n"+ "Số lượng: " +  ta.soluong;
        return  kq;
    }
}
