package QLBCoffee.HeThong.SanPham;

import QLBCoffee.HeThong.SanPham.SanPham;

import java.util.ArrayList;
import java.util.Scanner;

public class ThucAn extends SanPham {
	private static int dem = 0;
	private int maTA ;
	{dem++; maTA=dem;}
	private boolean anChay = false;
	ArrayList<SanPham> ds = new ArrayList<>();
	ArrayList<SanPham> dsdc = new ArrayList<>();	//dsdc = danh sách đồ chay
	ArrayList<SanPham> dsdm = new ArrayList<>();	//dsdm = danh sách đồ mặn
	public ThucAn(){
		super();
	}
	public ThucAn(String tsp, int gb, String tdb, String ttb){
		super(tsp, gb, tdb, ttb);
	}
	public String MaTA(){
		String kq = Integer.toString(this.maTA);
		if(kq.matches("\\d{1}"))
		{
			kq = "TA00" + kq;
		}
		else if(kq.matches("\\d{2}"))
		{
			kq = "TA0" + kq;
		}
		return kq;
	}
	public void NhapThucAn(Scanner scanner){
		MaTA();
		System.out.println("Nhập tên thức ăn: ");
		this.tenSP = scanner.nextLine();
		System.out.println("Nhập giá bán: ");
		this.giaBan = Integer.parseInt(scanner.nextLine());
		System.out.println("Thời điểm bán: ");
		this.thoiDiemBan = scanner.nextLine();
		System.out.println("Tình trạng(còn/hết): ");
		this.tinhTrang = scanner.nextLine();
		System.out.println("Có thể ăn chay(Y/N)");
		String chon2 = scanner.nextLine();
		if(!chon2.equalsIgnoreCase("y"))
			this.anChay = false;
		else
			this.anChay = true;
	}
	int soluong;
	public void NhapTT(Scanner scanner){
		System.out.println("Nhập tên thức ăn: ");
		this.tenSP = scanner.nextLine();
		System.out.println("Nhập số lượng: ");
		this.soluong = Integer.parseInt(scanner.nextLine());
	}


	@Override
	public String toString() {
		if(this.anChay = true)
			return super.toString() + "\nCó thể ăn chay\n"+"Mã sản phẩm: "+ MaTA();
		else
			return super.toString() + "\nKhông thể ăn chay\n"+"Mã sản phẩm:  "+ MaTA();
	}
}