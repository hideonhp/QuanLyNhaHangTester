package QLBCoffee.HeThong.SanPham;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class QLSanPham {
    ArrayList<SanPham> ds = new ArrayList<>();
    public void them(SanPham sp) {
        // TODO - implement SanPham.Themz
        this.ds.add(sp);
    }
    public void xoa(SanPham sp) {
        // TODO - implement SanPham.Xoa
        this.ds.remove(sp);
    }

    public QLSanPham timKiem(String kw) {
        // TODO - implement SanPham.TimKiem
        QLSanPham qlsp = new QLSanPham();
        for (SanPham sp:this.ds)
            if(sp.getTenSP().contains(kw))
                qlsp.them(sp);
        return qlsp;
    }

    public void nhapThucAn(Scanner scanner) throws ParseException {
        do {
                ThucAn sp = new ThucAn();
                sp.NhapThucAn(scanner);
                them(sp);
                System.out.println("Muốn tiếp tục?(Y/N)");
                String chon = scanner.nextLine();
                if (!chon.equalsIgnoreCase("y"))
                    break;
            }while (true);
        }
    public void nhapThucUong(Scanner scanner) throws ParseException {
        do {
            ThucUong sp = new ThucUong();
            sp.NhapThucUong(scanner);
            them(sp);
            System.out.println("Muốn tiếp tục?(Y/N)");
            String chon = scanner.nextLine();
            if (!chon.equalsIgnoreCase("y"))
                break;
        }while (true);
    }
    public String LayTen(){
        String kq = null;
        for(int i = 0; i < this.ds.size(); i++) {
             kq = this.ds.get(i).tenSP;
        }
        return kq;
    }
    public int LayGia(){
        int kq = 0;
        for(int i = 0; i < this.ds.size(); i++) {
            kq = this.ds.get(i).giaBan;
        }
        return kq;
    }

    @Override
    public String toString() {
        String kq = "";
        for(SanPham sp: this.ds)
            kq += sp +"\n";
        return kq;
    }
}
