package QLBCoffee.HeThong;

import java.io.FileNotFoundException;

public class DatTruoc extends DatBan {

	private int tgDen;

	public DatTruoc(String tsp, int slg) throws FileNotFoundException {
		super(tsp, slg);
	}
}