package QLBCoffee.HeThong;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class TKDT {

	protected static int maHoaDon;
	protected int chiPhiPhatSinh;
	protected static int maNhanVien;
	HoaDon hd = new HoaDon();
	QLHoaDon dshd = new QLHoaDon();

	public TKDT() throws FileNotFoundException {
	}

	public int getMaHoaDon() {
		return this.maHoaDon;
	}

	public void setMaHoaDon(int maHoaDon) {
		this.maHoaDon = maHoaDon;
	}

	public int getMaNhanVien() {
		return this.maNhanVien;
	}

	public void setMaNhanVien(int maNhanVien) {
		this.maNhanVien = maNhanVien;
	}

	public int TinhDT() {
		// TODO - implement TKDT.TinhDT
		int tam = 0;
		for (HoaDon hd: dshd.ds) {
			tam += hd.tongTien;
		}
		return tam;
	}

	public int LoiNhuan() {
		// TODO - implement TKDT.LoiNhuan
		return TinhDT() - chiPhiPhatSinh;
	}

	public void Nhap(Scanner scanner) {
		// TODO - implement NhanVien.Them
		System.out.println("Nhập chi phí phát sinh: ");
		this.chiPhiPhatSinh = Integer.parseInt(scanner.nextLine());
	}


	@Override
	public String toString() {
		return String.format("Tổng doanh thu: %d\n" +
				"Tổng lợi nhuận: %d",this.TinhDT(),this.LoiNhuan());
	}
}