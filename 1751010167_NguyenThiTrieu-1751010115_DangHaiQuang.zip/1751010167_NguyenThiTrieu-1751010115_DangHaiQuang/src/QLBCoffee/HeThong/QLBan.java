package QLBCoffee.HeThong;

import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class QLBan {
	FileInputStream dulieulay = new FileInputStream("I:\\BaiGiuaKiMonJava\\src\\QLBCoffee\\HeThong\\duLieuBan.txt");
	FileOutputStream dulieunhap = new FileOutputStream("I:\\BaiGiuaKiMonJava\\src\\QLBCoffee\\HeThong\\duLieuBan.txt");
	private int maBan;
	private final int sucChua = 6;
	private boolean tinhTrang;
	ArrayList<DatBan> ds = new ArrayList<>();
	public QLBan() throws FileNotFoundException {
	}

	public boolean KiemTraTrong() throws IOException {
		// TODO - implement QLBan.KiemTraTrong
		DatBan db = new DatBan();
		int i = 0;
		while ((i = dulieulay.read()) != -1 ) {
			if (db.maBan == (char)i) {
				return true;

			} else {
				return false;
			}
		}
		return false;
	}

	public void them(DatBan db) throws IOException {
		// TODO - implement QLBan.Them
		if(KiemTraTrong() == false)
			dulieunhap.write(this.maBan);
				this.ds.add(db);
	}

	public void xoa() {
		// TODO - implement QLBan.Xoa
		throw new UnsupportedOperationException();
	}

	public void timBan(int db) throws IOException {
		// TODO - implement QLBan.TimBan
		int i = 0;
		while ((i = dulieulay.read()) != -1 ) {
			if (db == (char)i)
				System.out.println("Đã tìm thấy bàn của bạn tìm");
		}
	}

	public void nhapBan(Scanner scanner) throws ParseException, IOException {
		do {
			DatBan db = new DatBan();
			db.Nhap(scanner);
			them(db);
			System.out.println("Muốn tiếp tục?(Y/N)");
			String chon = scanner.nextLine();
			if (!chon.equalsIgnoreCase("y"))
				break;
		} while (true);
	}
	@Override
	public String toString() {
		String kq = "";
		for (DatBan db: this.ds)
			kq += db.tenSanPham + "\n" + db.soLuong;
		return kq;
	}

}