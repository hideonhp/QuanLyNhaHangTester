package QLBCoffee.HeThong;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class SanPham {

	protected String maSP ;
	protected String tenSP;
	protected int giaBan;
	protected boolean tinhTrang = false;
	protected String thoiDiemBan;

	public SanPham(){

	}
	public SanPham(String msp,String tsp, int gb, String tdb){
		this.setMaSP(msp);
		this.setTenSP(tsp);
		this.setGiaBan(gb);
		this.thoiDiemBan = tdb;
	}
	public SanPham(String msp,String tsp, int gb){
		this.setMaSP(msp);
		this.setTenSP(tsp);
		this.setGiaBan(gb);
	}
	public String getTenSP() {
		return this.tenSP;
	}

	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}

	public int getGiaBan() {
		return this.giaBan;
	}

	public void setGiaBan(int giaBan) {
		this.giaBan = giaBan;
	}
	public void NhapSP(Scanner scanner) {
		System.out.println("Mã sản phẩm:");
		this.maSP = scanner.nextLine();
		System.out.println("Tên sản phẩm:");
		this.tenSP = scanner.nextLine();
		System.out.println("Gía Bán:");
		this.giaBan = Integer.parseInt(scanner.nextLine());
		System.out.println("Thời điểm bán:");
		this.thoiDiemBan = scanner.nextLine();
		System.out.println("Tình Trạng :");
		String tt = scanner.nextLine();
		if(tt != "Còn Bán")
			this.tinhTrang = false;
		else
			this.tinhTrang = true;
	}

	public String getMaSP() {
		return maSP;
	}

	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}

	@Override
	public String toString() {
		String kq = String.format("Mã sản phẩm: %s\nTên sản phẩm: %s\nGía bán: %s\nThời điểm bán: %s\nTình trạng: %s",this.maSP,
				this.tenSP,this.giaBan,this.thoiDiemBan,this.tinhTrang);
		return kq;
	}
}